# Frontend handoff — AmTree Lunar Navigator ⇄ backend

Everything below was executed against the running backend; the JSON in
`frontend_package/examples/api/` is the verbatim output of those calls.

## 1. Start

```bash
# once
py -3.14 -m venv .venv && .venv/Scripts/python -m pip install -r requirements.txt
.venv/Scripts/python scripts/fetch_data.py          # kernels + DEMs (skip if data/raw is already populated)
.venv/Scripts/python scripts/build_package.py       # catalog, regions, points, render frame, GLB

# every time
.venv/Scripts/python -m uvicorn llsn.api:app --app-dir backend --port 8000
```

- API base: `http://localhost:8000` · OpenAPI UI: `/docs` · schema: `/openapi.json`
- CORS: any `http://localhost:*` / `http://127.0.0.1:*` origin; add others with `LLSN_CORS_ORIGINS=https://a,https://b`.
- Static files: `/package/...` (this folder) and `/assets/terrain/*.glb`.

## 2. Use the adapter (one file, no dependencies)

`frontend_package/adapter/llsn-adapter.mjs` contains the only coordinate conversion, the camera
framing, the API client (polling + stale-response guard) and the panel view model.
`frontend_package/examples/panel_flow.mjs` is the whole flow in ~70 lines:
`node frontend_package/examples/panel_flow.mjs`.

```js
import { LlsnClient, makeSceneAdapter, frameTargets, toPanelRow, toPanelHeader, utcInputToIso } from './adapter/llsn-adapter.mjs';
const api = new LlsnClient('http://localhost:8000');
```

## 3. Catalog: regions and analysis points come from the backend

```js
const catalog = await api.getCatalog();                    // GET /api/v1/regions  (9 regions)
const { analysis_points } = await api.getSites({ role: 'frontend_study_location' });   // the 6 panel points
```

Do not keep a coordinate list in the frontend. Two separate entity types:

| entity | id example | what it is |
|---|---|---|
| region | `malapert-massif` | one of NASA's nine candidate regions (Oct 2024) |
| analysis point | `pgda-site23-malapert-massif` | a coordinate where visibility is computed; **marker id = table row id** |

The six draft locations are served unchanged (same names, same coordinates to 4 decimals). They are
the centres of the PGDA 5 m/px LOLA site DEM tiles (`coordinate_source` in each point). Only
"Malapert Massif" has a `region_id` (it lies inside the Malapert Massif grid extent); the other five
are `region_id: null` — four of them belong to the 2022 list and are not among the nine regions.

Region geometry today: **2 of 9** have verified geometry (`geometry_status: "verified_against_source_files"`,
Malapert Massif and Haworth, from the USGS grids). The other 7 have `geometry_status: "unavailable"`,
`boundary: null`, and a `label_position` with `status: "approximate"` (centre of the nearest IAU-named
feature — fine for a label, wrong by up to tens of km). Style them differently or hide them.

## 4. Place things on the globe

```js
const renderFrame = await api.getRenderConfig();           // GET /api/v1/render-config
const scene = makeSceneAdapter(renderFrame, { adapter: 'threejs_y_up_texture_lon0_center', sceneRadius: MOON_RADIUS });
console.assert(scene.selfCheck().length === 0);

marker.position.fromArray(scene.position(point.render_position.unit_vector, 0.002));   // 0.2 % above the sphere
marker.userData.id = point.analysis_point_id;                                           // same id as the row

// region outline: a 3-D polyline, never triangulate lat/lon yourself
const pts = region.boundary.ring_unit_vectors.map((u) => new THREE.Vector3(...scene.position(u, 0.001)));
// filled patch: region.boundary.surface_patch { vertices_unit, triangles }
```

**The adapter name is the one thing to confirm in your code** (we had no access to it). Canonical frame:
origin at the Moon centre, +X = (0°N, 0°E), +Y = (0°N, 90°E), +Z = north pole.

| adapter | use when |
|---|---|
| `threejs_y_up_texture_lon0_center` (default) | unrotated `THREE.SphereGeometry`, equirectangular texture −180…180 (lon 0 in the middle) |
| `threejs_y_up_texture_lon0_left` | same, texture 0…360 (lon 0 on the left edge) |
| `canonical_z_up` | Z-up scenes |

If the Moon mesh (or a parent) is rotated, either parent markers to the mesh or multiply that rotation in.
Check visually with `render-config.named_check_points`: the Tycho and Copernicus markers must sit on those
craters; `south_pole` on the rim of Shackleton. If Tycho appears mirrored east–west, switch adapter.
Matrices: `matrix3_rows[i][j]` = row *i*, column *j*; `p_scene = R · (M · u)`; `matrix4_column_major`
goes straight into `THREE.Matrix4.fromArray`.

## 5. Zoom

```js
// one region
const c = region.camera_suggestion;        // target / position in globe radii, 45° vertical FOV, no panel
// all selected markers, panel docked right
const f = frameTargets(points.map((p) => p.render_position.unit_vector),
                       { fovDeg: camera.fov, width: innerWidth, height: innerHeight, panelRightPx: panel.offsetWidth });
camera.position.fromArray(scene.position(f.position));     // position/target are already full vectors
controls.target.fromArray(scene.position(f.target));
camera.up.fromArray(scene.direction(f.up));
camera.setViewOffset(innerWidth, innerHeight, f.viewOffsetPx.x, 0, innerWidth, innerHeight);   // centre in the free area
```
`region.bounding_volume` (sphere: centre unit vector + angular radius) is available for custom framing.

## 6. Panel request, loading state, job polling

```js
const { stale, result } = await api.compare({
  analysis_point_ids: catalog.default_panel_analysis_point_ids,
  landing_time_utc: utcInputToIso(dateInput.value),        // '2027-01-10T12:00' -> '2027-01-10T12:00:00Z'
  mission_duration_hours: 72,
  max_consecutive_darkness_hours: 12,
  // observer_height_m: 2.0   (default 2 m above the DEM surface when omitted)
}, { onStatus: (s) => setBadge(s) });                      // 'computing' -> 'computed' | 'partial' | 'failed'
if (stale) return;                                         // a newer request superseded this one: ignore
renderHeader(toPanelHeader(result)); renderRows(result.rows.map(toPanelRow));
```

Raw protocol: `POST /api/v1/comparisons` → `202 {job_id, status, status_url, result_url, comparison_id, request_id, period}`
(or `200` with `result` inline when cached) → poll `GET status_url` until `succeeded|failed` →
`GET result_url`. `?wait_s=30` makes the POST block and return the result inline.
The analysed period is `[landing_time_utc, landing_time_utc + mission_duration_hours]`; it is echoed in
`result.period.start_utc / end_utc`. Timestamps without a UTC offset are rejected (HTTP 422).

Row → panel mapping (`toPanelRow`):

| panel | field | note |
|---|---|---|
| name / coordinates | `name`, `coordinates.lat_deg/lon_deg` | planetocentric, east-positive, MOON_ME |
| Sunlight | `sun_visible_hours` | ≥ 50 % of the solar disc above the terrain horizon |
| Earth visibility | `earth_visible_hours` | ≥ 50 % of the Earth disc above the terrain horizon |
| Longest dark | `longest_darkness_hours` | longest continuous interval of certain darkness |
| "56 h Sun + Earth" | `sun_and_earth_visible_hours` | simultaneous |
| status text | `constraint_message` | names only the limits evaluated, e.g. "Meets darkness limit" |
| dot colour | `constraint_status` | `feasible` · `infeasible` · `indeterminate` · `not_evaluated` |
| chevron | `details_url`, `intervals_url`, `timeseries_url` | |
| "4 of 6 meet limit" | `counts_message`, `counts.{compliant,non_compliant,indeterminate}` | from constraint results |
| "72-HOUR SITE SCREENING" | `title_hint` | follows the selected duration |
| "Demo data" badge | replace only if `is_demo_data === false && data_status ∈ {computed, partial}` | `toPanelHeader().isReal` |

Unknown ≠ zero: a metric is `null` when it could not be computed (`data_status: "failed"`, see `error`) and
`unknown_hours > 0` when part of the timeline is undetermined (`data_status: "partial"`). `formatHours(null)`
renders `—`. Never fall back to demo numbers.

Changing date or duration → call `compare` again (new `comparison_id`). Changing only the darkness limit →
same call; the backend reuses the analyses (`science_id` unchanged, `reuse.analyses_reused_from_cache`) and
answers in ~0.1–0.2 s.

## 7. "Delay +48 h"

```js
const { stale, result } = await api.delay(current.comparison_id, 48, { onStatus: setBadge });
```
`POST /api/v1/comparisons/{id}/delay {"delay_hours": 48}` keeps points, duration and requirements, shifts the
landing, and links the two: `result.derived_from = {comparison_id, relation: "delay", delay_hours}`; every row
has `delta_vs_parent` (hour differences, status and rank before/after) and `parent_counts`. Update the date
input from `result.period.landing_time_utc`.

## 8. Site details

```js
const [summary, intervals, series] = await Promise.all([
  api.getAnalysis(row.analysis_id), api.getIntervals(row.analysis_id), api.getTimeseries(row.analysis_id, 10)]);
```
- `summary`: analysed coordinates, period, `method` (observer height, horizon model, time step, definitions),
  `metrics`, `sources` (DEM + kernels with checksums), `limitations`.
- `intervals`: `sun`, `earth`, `sun_and_earth`, `darkness` → `[{start_utc, end_utc, start_offset_s, duration_hours,
  state: visible|not_visible|unknown, clipped_by_period_start/end}]`. Draw timelines from these.
- `timeseries.samples[]`: `time_utc`, Sun/Earth azimuth & elevation, horizon elevation under each body, disc
  fractions, statuses, `quality_flags`. Every sample is `sample_kind: "computed"`; anything you interpolate for
  animation is yours to label.
- Failed / undetermined limits: `row.constraint_results[] = {constraint, status, value, threshold, reason}`.
- Horizon profile for a skyline plot: `GET /api/v1/sites/{id}/horizon?stride=4`.

## 9. Render lighting is separate from visibility results

Site visibility comes only from the analysis. If the scene light should follow the real Sun:
`light.position = scene.direction(sample.sun_direction_moon_me) * far` (also `earth_direction_moon_me`), or
`GET /api/v1/ephemeris/directions?time_utc=...`. These are Moon-centre directions in MOON_ME; never feed a
site's azimuth/elevation to the global light.

## 10. Errors

| situation | what you get | show |
|---|---|---|
| backend down | `LlsnApiError` status 0 | "Backend unreachable", keep the demo badge |
| invalid input | HTTP 422, `detail` string or list | the message |
| job failed | job `status: "failed"`, `error` | "Computation failed" |
| one point failed | row `data_status: "failed"`, metrics `null`, `error` | `—` in that row |
| server restarted mid-job | job `failed`, "interrupted…" | resubmit |

## 11. Beyond the panel (implemented, optional for the first integration)

- Nine-region table: `POST /api/v1/comparisons {region_ids: [...], point_selection: "representative"|"all", ...}`
  → `result.region_summaries[]` with `analysis_scope`, `recommended_point_id`, ranges; regions without geometry
  come back `data_status: "unavailable"` with a reason.
- Arrival windows: `api.searchWindows({search_start_utc, search_end_utc, stay_duration_hours, requirements})`.
- Scenarios / emergencies: `api.scenario({type, base, changes})` → changed requirements + before/after ranking.
- Terrain: `region.terrain_asset_url` (GLB, metres, +Y up, local frame) + `…-80m.json` with `local_to_moon_me`.

Examples of every response: `frontend_package/examples/api/`.

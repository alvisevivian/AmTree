// Lunar Landing Site Navigator - frontend adapter (no dependencies, works in browsers and Node >= 18).
//
// One place for: science -> scene coordinates, camera framing, API calls with job polling,
// stale-response protection and the panel view model. Marker id == table row id ==
// analysis_point_id everywhere.

// ----------------------------------------------------------------------------- coordinates
/** Unit vector in the canonical science frame (MOON_ME): +X=(0N,0E), +Y=(0N,90E), +Z=north. */
export function latLonToUnit(latDeg, lonDeg) {
  const lat = (latDeg * Math.PI) / 180, lon = (lonDeg * Math.PI) / 180;
  return [Math.cos(lat) * Math.cos(lon), Math.cos(lat) * Math.sin(lon), Math.sin(lat)];
}

/** p' = M p with M given as row-major nested arrays (render-frame.json: adapters[name].matrix3_rows). */
export function applyMatrix3(m, v) {
  return [0, 1, 2].map((i) => m[i][0] * v[0] + m[i][1] * v[1] + m[i][2] * v[2]);
}

/**
 * The single science -> scene conversion.
 * renderFrame: GET /api/v1/render-config; opts.adapter: adapter name (set ONCE for the app);
 * opts.sceneRadius: Moon mesh radius in scene units; opts.lift: fraction of the radius to raise markers;
 * opts.center: world position of the Moon mesh.
 */
export function makeSceneAdapter(renderFrame, opts = {}) {
  const name = opts.adapter ?? renderFrame.default_adapter;
  const a = renderFrame.adapters[name];
  if (!a) throw new Error(`unknown render adapter '${name}'`);
  const M = a.matrix3_rows, R = opts.sceneRadius ?? 1, c = opts.center ?? [0, 0, 0];
  const direction = (unit) => applyMatrix3(M, unit);           // for light / Earth directions
  const position = (unit, lift = opts.lift ?? 0) => direction(unit).map((x, i) => c[i] + x * R * (1 + lift));
  return {
    name, matrix3Rows: M, sceneRadius: R,
    direction, position,
    fromLatLon: (lat, lon, lift) => position(latLonToUnit(lat, lon), lift),
    /** Returns the list of control points that do not match (empty = adapter math is consistent). */
    selfCheck(tol = 1e-9) {
      return renderFrame.control_points.filter((p) => {
        const got = direction(latLonToUnit(p.lat_deg, p.lon_deg)), exp = p.expected[name];
        return got.some((g, i) => Math.abs(g - exp[i]) > tol);
      }).map((p) => p.id);
    },
  };
}

const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const norm = (a) => { const n = Math.hypot(...a); return a.map((x) => x / n); };
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];

/**
 * Camera that contains every target (unit vectors, canonical frame), leaving the side panel free.
 * Returns canonical-frame vectors in units of the globe radius: convert with adapter.position()/direction().
 * `viewOffsetPx` is meant for THREE.PerspectiveCamera.setViewOffset(width, height, x, 0, width, height):
 * it shifts the picture so the targets are centred in the area not covered by the panel.
 */
export function frameTargets(units, { fovDeg = 45, width, height, panelRightPx = 0, margin = 1.35, minAngularRadiusDeg = 0.3 } = {}) {
  if (!units.length) throw new Error('no targets');
  const center = norm(units.reduce((s, u) => [s[0] + u[0], s[1] + u[1], s[2] + u[2]], [0, 0, 0]));
  let ang = Math.max(...units.map((u) => Math.acos(Math.min(1, dot(u, center)))));
  ang = Math.max(ang, (minAngularRadiusDeg * Math.PI) / 180);
  const r = Math.sin(ang) * margin;                              // bounding-sphere radius (globe radii)
  const freeW = Math.max(width - panelRightPx, 1);
  const v = (fovDeg * Math.PI) / 180;
  const h = 2 * Math.atan(Math.tan(v / 2) * (freeW / height));  // horizontal FOV of the free area
  const dist = r / Math.sin(Math.min(v, h) / 2);
  const target = center.map((x) => x * Math.cos(ang));          // centre of the spherical cap
  const position = center.map((x, i) => target[i] + x * dist);
  let up = [1, 0, 0];                                           // (0N,0E): Earth-facing meridian up
  if (Math.abs(dot(up, center)) > 0.95) up = [0, 0, 1];
  up = norm(cross(cross(center, up), center));
  return { target, position, up, distance: dist, angularRadiusDeg: (ang * 180) / Math.PI,
           viewOffsetPx: { x: panelRightPx / 2, y: 0 }, fovDeg,
           assumptions: ['perspective camera', 'fovDeg is the vertical FOV', 'panel docked on the right'] };
}

// ----------------------------------------------------------------------------- API client
export class LlsnApiError extends Error {
  constructor(message, status, detail) { super(message); this.status = status; this.detail = detail; }
}

export class LlsnClient {
  constructor(baseUrl = 'http://localhost:8000', { fetchImpl = globalThis.fetch, pollMs = 400, timeoutMs = 180000 } = {}) {
    this.base = baseUrl.replace(/\/$/, ''); this.fetch = fetchImpl; this.pollMs = pollMs; this.timeoutMs = timeoutMs;
    this._seq = 0; this._latest = {};
  }
  async _json(path, init) {
    let res;
    try { res = await this.fetch(this.base + path, init); }
    catch (e) { throw new LlsnApiError(`backend unreachable: ${e.message}`, 0); }
    const body = await res.json().catch(() => null);
    if (!res.ok) throw new LlsnApiError(typeof body?.detail === 'string' ? body.detail : `HTTP ${res.status}`, res.status, body?.detail);
    return body;
  }
  _post(path, body) { return this._json(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); }

  getCatalog() { return this._json('/api/v1/regions'); }
  getRegion(id) { return this._json(`/api/v1/regions/${id}`); }
  getRenderConfig() { return this._json('/api/v1/render-config'); }
  getSites(params = {}) { return this._json('/api/v1/sites?' + new URLSearchParams(params)); }
  getAnalysis(id) { return this._json(`/api/v1/analyses/${id}`); }
  getIntervals(id) { return this._json(`/api/v1/analyses/${id}/intervals`); }
  getTimeseries(id, stride = 1) { return this._json(`/api/v1/analyses/${id}/timeseries?stride=${stride}`); }
  getDirections(timeUtc) { return this._json('/api/v1/ephemeris/directions?' + new URLSearchParams({ time_utc: timeUtc })); }

  /**
   * Submit + poll. `channel` groups requests that replace each other (e.g. 'panel'): if a newer
   * request was started on the same channel, the older one resolves to { stale: true } and must be ignored.
   * onStatus receives 'computing' | 'computed' | 'partial' | 'failed' plus the job.
   */
  async _run(path, body, { channel = 'default', onStatus } = {}) {
    const seq = ++this._seq; this._latest[channel] = seq;
    const requestId = `${channel}-${seq}-${Date.now()}`;
    const stale = () => this._latest[channel] !== seq;
    onStatus?.('computing', null);
    let job = await this._post(path, { ...body, request_id: requestId });
    const t0 = Date.now();
    while (job.status === 'queued' || job.status === 'running') {
      if (stale()) return { stale: true, requestId };
      if (Date.now() - t0 > this.timeoutMs) throw new LlsnApiError('job timed out', 0);
      onStatus?.('computing', job);
      await new Promise((r) => setTimeout(r, this.pollMs));
      job = await this._json(job.status_url);
    }
    if (stale()) return { stale: true, requestId };
    if (job.status === 'failed') { onStatus?.('failed', job); throw new LlsnApiError(job.error ?? 'job failed', 0, job); }
    const result = job.result ?? await this._json(job.result_url);
    onStatus?.(result.data_status ?? 'computed', job);
    return { stale: false, requestId, job, result };
  }
  /** Panel request. req: {analysis_point_ids?, landing_time_utc, mission_duration_hours, max_consecutive_darkness_hours?, observer_height_m?} */
  compare(req, opts = {}) { return this._run('/api/v1/comparisons', req, { channel: 'panel', ...opts }); }
  /** "Delay +48 h": same points/duration/requirements, landing shifted, linked to the parent comparison. */
  delay(comparisonId, delayHours = 48, opts = {}) {
    return this._run(`/api/v1/comparisons/${comparisonId}/delay`, { delay_hours: delayHours }, { channel: 'panel', ...opts });
  }
  searchWindows(req, opts = {}) { return this._run('/api/v1/window-searches', req, { channel: 'windows', ...opts }); }
  scenario(req, opts = {}) { return this._run('/api/v1/scenarios', req, { channel: 'scenario', ...opts }); }
}

// ----------------------------------------------------------------------------- view model
/** Local datetime-input value (interpreted as UTC, as the panel labels it) -> ISO 8601 UTC string. */
export function utcInputToIso(value) { return (value.length === 16 ? value + ':00' : value) + 'Z'; }

export const UNKNOWN = '—';
/** null/undefined -> "—" (unknown is never shown as 0). */
export function formatHours(v, digits = 0) { return v == null ? UNKNOWN : `${v.toFixed(digits)} h`; }

/** One comparison row -> what the panel shows. id is also the marker id. */
export function toPanelRow(row) {
  const unknown = row.unknown_hours != null && row.unknown_hours > 0;
  return {
    id: row.analysis_point_id, markerId: row.marker_id, regionId: row.region_id, name: row.name,
    coordinatesLabel: `${row.coordinates.lat_deg.toFixed(4)}°, ${row.coordinates.lon_deg.toFixed(4)}°`,
    sunlight: formatHours(row.sun_visible_hours), earthVisibility: formatHours(row.earth_visible_hours),
    longestDark: formatHours(row.longest_darkness_hours),
    overlapLabel: row.sun_and_earth_visible_hours == null ? `${UNKNOWN} Sun + Earth` : `${row.sun_and_earth_visible_hours.toFixed(0)} h Sun + Earth`,
    statusLabel: row.constraint_message,              // describes only the limits actually evaluated
    status: row.constraint_status,                    // feasible | infeasible | indeterminate | not_evaluated
    dataStatus: row.data_status,                      // computed | partial | failed
    hasUnknown: unknown, unknownLabel: unknown ? `${row.unknown_hours.toFixed(1)} h unknown` : null,
    error: row.error, detailsUrl: row.details_url, analysisId: row.analysis_id,
    provenance: row.analysis_method && `${row.analysis_method.versions.ephemeris} · ${row.analysis_method.versions.dem}`,
  };
}

/** Whole comparison -> panel header. Replace the "Demo data" badge only when isReal is true. */
export function toPanelHeader(result) {
  return {
    title: result.title_hint,                                           // follows the selected duration
    countsLabel: result.counts_message,
    counts: result.counts,
    isReal: result.is_demo_data === false && ['computed', 'partial'].includes(result.data_status),
    badge: result.data_status === 'computed' ? 'Computed · LOLA terrain + SPICE ephemeris'
         : result.data_status === 'partial' ? 'Partially computed · some values unknown' : 'Computation failed',
    startUtc: result.period.start_utc, endUtc: result.period.end_utc,
    comparisonId: result.comparison_id, derivedFrom: result.derived_from,
  };
}

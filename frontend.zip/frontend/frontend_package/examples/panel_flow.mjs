// End-to-end frontend flow against the running backend:  node frontend_package/examples/panel_flow.mjs [baseUrl]
// catalog -> markers -> comparison (job polling) -> rows -> Delay +48 h -> site details.
import assert from 'node:assert/strict';
import { LlsnClient, makeSceneAdapter, frameTargets, toPanelRow, toPanelHeader, utcInputToIso, latLonToUnit } from '../adapter/llsn-adapter.mjs';

const api = new LlsnClient(process.argv[2] ?? 'http://localhost:8000');

// 1. catalog and analysis points come from the backend (no local coordinate list)
const [catalog, renderFrame] = await Promise.all([api.getCatalog(), api.getRenderConfig()]);
const { analysis_points: points } = await api.getSites({ role: 'frontend_study_location' });
console.log(`regions: ${catalog.regions.length}, panel points: ${points.length}`);

// 2. one adapter for every conversion; control points prove matrix order and conventions
const adapter = makeSceneAdapter(renderFrame, { sceneRadius: 1 });
assert.deepEqual(adapter.selfCheck(), [], 'adapter control points mismatch');
for (const p of points) {   // lat/lon -> unit vector must equal the backend's render_position
  const u = latLonToUnit(p.lat_deg, p.lon_deg);
  p.render_position.unit_vector.forEach((x, i) => assert.ok(Math.abs(x - u[i]) < 1e-6));
}
const markers = points.map((p) => ({ id: p.analysis_point_id, position: adapter.position(p.render_position.unit_vector, 0.002) }));
console.log('marker', markers[0]);

// 3. camera containing all markers, with a 940 px panel on the right of a 2505x1484 viewport
const cam = frameTargets(points.map((p) => p.render_position.unit_vector), { fovDeg: 45, width: 2505, height: 1484, panelRightPx: 940 });
console.log('camera', { position: adapter.position(cam.position.map((x) => x)), target: adapter.position(cam.target), viewOffsetPx: cam.viewOffsetPx });

// 4. panel request (datetime-local value is UTC)
const req = { analysis_point_ids: catalog.default_panel_analysis_point_ids, landing_time_utc: utcInputToIso('2027-01-10T12:00'),
              mission_duration_hours: 72, max_consecutive_darkness_hours: 12 };
const first = await api.compare(req, { onStatus: (s) => console.log('status:', s) });
assert.equal(first.stale, false);
const header = toPanelHeader(first.result);
console.log(header.title, '|', header.countsLabel, '|', header.badge);
console.table(first.result.rows.map(toPanelRow).map(({ id, sunlight, earthVisibility, longestDark, overlapLabel, statusLabel }) =>
  ({ id, sunlight, earthVisibility, longestDark, overlapLabel, statusLabel })));
// row <-> marker share the same id
assert.deepEqual(first.result.rows.map((r) => r.marker_id).sort(), markers.map((m) => m.id).sort());

// 5. stale-response guard: an older request is ignored when a newer one was started
const [older, newer] = await Promise.all([api.compare({ ...req, mission_duration_hours: 96 }), api.compare({ ...req, mission_duration_hours: 48 })]);
assert.equal(older.stale, true); assert.equal(newer.stale, false);
assert.equal(toPanelHeader(newer.result).title, '48-hour site screening');

// 6. Delay +48 h keeps duration and limits and links to the parent
const delayed = await api.delay(first.result.comparison_id, 48);
assert.equal(delayed.result.derived_from.comparison_id, first.result.comparison_id);
assert.equal(delayed.result.period.start_utc, '2027-01-12T12:00:00Z');
console.log('delayed:', toPanelHeader(delayed.result).countsLabel, delayed.result.rows[0].delta_vs_parent);

// 7. threshold-only change reuses the science (same science_id)
const stricter = await api.compare({ ...req, max_consecutive_darkness_hours: 6 });
assert.equal(stricter.result.science_id, first.result.science_id);
assert.equal(stricter.result.reuse.analyses_reused_from_cache, stricter.result.rows.length);

// 8. site details: timelines for Sun, Earth, overlap, darkness + global light direction
const row = first.result.rows.find((r) => r.analysis_point_id === 'pgda-site23-malapert-massif');
const [summary, intervals, series] = await Promise.all([api.getAnalysis(row.analysis_id), api.getIntervals(row.analysis_id), api.getTimeseries(row.analysis_id, 30)]);
console.log('detail:', summary.coordinates, summary.period.start_utc, '->', summary.period.end_utc, '| step', summary.period.step_s, 's');
console.log('sun intervals:', intervals.sun.map((i) => `${i.state} ${i.duration_hours} h`).join(', '));
console.log('darkness:', intervals.darkness.length, 'interval(s); samples:', series.samples.length);
console.log('light direction (scene):', adapter.direction(series.samples[0].sun_direction_moon_me));

// 9. errors and unknowns
await assert.rejects(api.compare({ ...req, landing_time_utc: '2027-01-10T12:00:00' }), /time zone/);       // naive timestamp
await assert.rejects(api.compare({ ...req, analysis_point_ids: ['nope'] }), /unknown analysis_point_ids/);
console.log('unknown value renders as:', toPanelRow({ ...row, sun_visible_hours: null }).sunlight);
console.log('OK');
